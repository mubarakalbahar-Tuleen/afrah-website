# Afrah Mubarak Al Sabah — Poet Website

Bilingual (English/Arabic) personal website with CMS.

## How to Edit Content

Go to **[afrahmalsabah.com/admin](https://afrahmalsabah.com/admin)** and log in with GitHub.

From the admin panel you can:
- **Write blog posts** (in English and Arabic)
- **Edit books** (titles, descriptions, cover images)
- **Update bio and site settings** (name, quote, photo, social links)

Changes are saved to this repo and automatically deployed via Cloudflare.

## Structure

```
index.html              → Main website
admin/
  index.html            → CMS admin panel
  config.yml            → CMS configuration
content/
  settings/about.md     → Bio, contact info, social links
  books/                → Book entries
  blog/                 → Blog posts
images/                 → Uploaded images
```
