---
name_en: "Afrah Mubarak Al Sabah"
name_ar: "أفراح مبارك الصباح"
subtitle_en: "Poet · Intellectual · Observer · Nature Lover"
subtitle_ar: "شاعرة · مثقفة · مراقبة · عاشقة للطبيعة"
quote_en: "A favourite line of poetry will go here..."
quote_ar: "سطر شعري مفضّل سيُضاف هنا..."
bio_en: >-
  Afrah Mubarak Al Sabah is a poet, intellectual, and keen observer of the
  world around her. With a deep love for nature and the written word, she
  weaves observations into verse that resonates across cultures and languages.


  She has published three collections of poetry. Her latest book, *Blue
  Passion*, has been translated into English, bridging the beauty of Arabic
  poetry with a global audience.
bio_ar: >-
  أفراح مبارك الصباح شاعرة ومثقفة ومراقبة دقيقة للعالم من حولها. بشغفها
  العميق بالطبيعة والكلمة المكتوبة، تنسج ملاحظاتها في أبيات شعرية تتردد
  أصداؤها عبر الثقافات واللغات.


  أصدرت ثلاث مجموعات شعرية. أحدث كتبها، *شغف أزرق*، تُرجم إلى الإنجليزية،
  ليكون جسراً يربط جمال الشعر العربي بالقارئ العالمي.
photo: ""
email: "amsoct@gmail.com"
instagram: "@afrahmalsabah"
twitter: "@afrahMAlSabah"
facebook: ""
---
