---
title_en: "Blue Passion"
title_ar: "شغف أزرق"
desc_en: "Her latest collection, translated into English."
desc_ar: "أحدث مجموعاتها الشعرية، مترجمة إلى الإنجليزية."
cover: ""
order: 1
---
